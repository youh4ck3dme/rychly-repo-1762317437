// This file can be used for future type definitions specific to the application.
